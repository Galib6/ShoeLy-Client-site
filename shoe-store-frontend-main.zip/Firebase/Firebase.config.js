// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCy0bJiwOnrLNnRICxl3e-wfguDEdyUEew",
  authDomain: "shoely-64f65.firebaseapp.com",
  projectId: "shoely-64f65",
  storageBucket: "shoely-64f65.appspot.com",
  messagingSenderId: "1086676766703",
  appId: "1:1086676766703:web:cf6f440f4c226ca874701a",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
