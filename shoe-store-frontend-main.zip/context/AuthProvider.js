import React, { createContext, useEffect, useState } from "react";
import {
  createUserWithEmailAndPassword,
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from "firebase/auth";
import app from "@/Firebase/Firebase.config";
import { API_URL } from "@/utils/urls";

export const AuthContext = createContext();
const auth = getAuth(app);

const AuthProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${API_URL}/api/cart`)
      .then((res) => res.json())
      .then((data) => {
        setCart(data);
      });
  }, []);

  const createUser = (email, password) => {
    //console.log(email)
    return createUserWithEmailAndPassword(auth, email, password);
  };
  const signIn = (email, password) => {
    setLoading(true);
    return signInWithEmailAndPassword(auth, email, password);
  };

  const logOut = () => {
    setLoading(true);
    return signOut(auth);
  };
  const updateUser = (userInfo) => {
    //console.log(userInfo)
    return updateProfile(auth.currentUser, userInfo);
  };
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      // //console.log('user observing');
      setUser(currentUser);
      // //console.log(currentUser)
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInwithGoolge = (provider) => {
    return signInWithPopup(auth, provider);
  };

  const authifo = {
    createUser,
    signIn,
    setUser,
    user,
    setLoading,
    loading,
    logOut,
    updateUser,
    signInwithGoolge,
    cart,
    setCart,
  };

  return (
    <AuthContext.Provider value={authifo}>{children}</AuthContext.Provider>
  );
};

export default AuthProvider;
