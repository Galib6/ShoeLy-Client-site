// export const STRAPI_API_TOKEN = process.env.NEXT_PUBLIC_STRAPI_API_TOKEN;

export const API_URL = "https://shoe-store-backend-main.vercel.app";
