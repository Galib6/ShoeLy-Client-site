import Signup from "@/components/Signup";
import React from "react";

const index = () => {
  return (
    <div>
      <Signup></Signup>
    </div>
  );
};

export default index;
