import Login from "@/components/Login";
import React from "react";

const index = () => {
  return (
    <div>
      <Login></Login>
    </div>
  );
};

export default index;
